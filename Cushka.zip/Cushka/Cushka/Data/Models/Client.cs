﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cushka.Data.Models
{
    public class Client: IdentityUser
    {
        public Client()
        {
            this.Orders = new HashSet<Order>();
        }
        public string FullName { get; set; }
        public virtual ICollection<Order>  Orders { get; set; }

    }
}
