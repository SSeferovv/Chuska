﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cushka.Data.Models
{
    public class Order
    {
        public Order()
        {
            this.Products = new HashSet<ProductOrder>();
        }
        public int Id { get; set; }
        public ICollection<ProductOrder> Products { get; set; }
        public bool OrderedOn { get; set; }
        public int ClientId { get; set; }
        public virtual Client Client { get; set; }
    }
}
