﻿using Cushka.Data;
using Cushka.Data.Models;
using Cushka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cushka.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext db;

        public ProductController(ApplicationDbContext db)
        {
            this.db = db;
        }
        [HttpGet]
        public IActionResult Index()
        {

            return this.View();
        }
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(InputProductModel input)
        {
            var product = new Product
            {
                Name = input.Name,
                Price = input.Price,
                Description = input.Description,
                Type = (Product.Type_)input.ProductType
            };
            db.Products.Add(product);
            db.SaveChanges();
            return Redirect("/");
        }
        public IActionResult Delete()
        {
            return View();
        }
       
        public IActionResult Details()
        {
            return View();
        }
        public IActionResult DetailsAdmin()
        {
            return View();
        }
        public IActionResult Edit()
        {
            return View();
        }
        public IActionResult All()
        {
            var model = db.Products.Select(x => new InputProductModel
            {
                Name = x.Name,
                Description = x.Description,
                Price = x.Price,

            }).ToList();
            return View(model);
        }
    }
    
}
